// eslint-disable-next-line import/no-extraneous-dependencies
import twosky from 'MainRoot/.twosky.json';

export const {
    languages: LANGUAGES,
    base_locale: BASE_LOCALE,
} = twosky[0];
