const BUILD_ENVS = {
    dev: 'development',
    prod: 'production',
};

const BASE_URL = 'control';

module.exports = {
    BUILD_ENVS,
    BASE_URL,
};
